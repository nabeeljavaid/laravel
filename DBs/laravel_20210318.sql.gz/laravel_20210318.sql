-- MySQL dump 10.13  Distrib 5.7.33, for Linux (x86_64)
--
-- Host: localhost    Database: laravel
-- ------------------------------------------------------
-- Server version	5.7.33-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Nabeel Javaid','nabeeljavaid.nmj@gmail.com','2021-03-17 02:52:47','$2y$10$nqZeeqP8GQRSe3PuGShaYeEkq6qbOEx8TnsRhX/SsRHZ7Zn/6FuKe','M4pPgG4LD4','2021-03-17 02:52:47','2021-03-17 06:30:06'),(2,'Jerrell Kulas','asporer@example.org','2021-03-17 02:52:47','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','MbPrCVBGrh','2021-03-17 02:52:47','2021-03-17 02:52:47'),(3,'Velma Schiller','brakus.everett@example.net','2021-03-17 02:52:47','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','qBA3MknplO','2021-03-17 02:52:47','2021-03-17 02:52:47'),(4,'Norma Pfannerstill','frederik95@example.org','2021-03-17 02:52:47','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','0anaLU56j0','2021-03-17 02:52:48','2021-03-17 02:52:48'),(5,'Aiyana Murray','sigmund83@example.org','2021-03-17 02:52:47','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','AKeROgptEX','2021-03-17 02:52:48','2021-03-17 02:52:48'),(6,'Suzanne Fadel IV','dkilback@example.net','2021-03-17 02:52:47','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','9IJ18VTrxt','2021-03-17 02:52:48','2021-03-17 02:52:48'),(7,'Dorian Spencer','ckoepp@example.org','2021-03-17 02:52:47','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','b2R5JOYSAX','2021-03-17 02:52:48','2021-03-17 02:52:48'),(8,'Zoie Torphy','cremin.sienna@example.net','2021-03-17 02:52:47','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','wHJ3qeQAMr','2021-03-17 02:52:48','2021-03-17 02:52:48'),(9,'Mr. Monroe Champlin','ferry.rickey@example.net','2021-03-17 02:52:47','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Hq4O9A9fxZ','2021-03-17 02:52:48','2021-03-17 02:52:48'),(10,'Lavonne Muller','esta.wyman@example.com','2021-03-18 03:11:27','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','nKr1BwOnTs','2021-03-18 03:11:27','2021-03-18 03:11:27'),(31,'Dr. Bert Howell','turner.oleta@example.net',NULL,'$2y$04$u6PwrPcOzzuSrr91m5pI7ulYsbTyMmUzWfdO2Ga2MVpbz/HKU4Toq',NULL,'2021-03-18 04:41:04','2021-03-18 04:41:04'),(32,'Lamont Lemke','ckris@example.org','2021-03-18 04:41:04','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','2ytWhdtAq3','2021-03-18 04:41:04','2021-03-18 04:41:04'),(33,'Lonnie Gulgowski PhD','joannie.yundt@example.net','2021-03-18 04:41:04','$2y$04$33hY0uGiLrw5MmsubEs5G.8ZDfG0ZhXAdTKD.zmYWrny27jp6mnlK','mPQNllORsO','2021-03-18 04:41:04','2021-03-18 04:41:04'),(35,'Test User 03','testuser3@mail.com',NULL,'$2y$10$lkhhZ8/6GyT9goXOTBan.Oj.jmUdEc83LnyyrCTNDoIIxtLBcBSJK',NULL,'2021-03-18 04:46:45','2021-03-18 04:46:45'),(36,'Prof. Eriberto Jerde PhD','kris.tyler@example.org',NULL,'$2y$04$z3yiG9d/Xqo0MhRQgWvxeOnvDJYYGzd7VUeLymlZmLyes3yDyIbfS',NULL,'2021-03-18 04:47:43','2021-03-18 04:47:43'),(37,'Lydia Stark','ofelia.adams@example.org','2021-03-18 04:47:43','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','VetNfgPyIF','2021-03-18 04:47:43','2021-03-18 04:47:43'),(38,'Prof. Bella Renner II','gibson.brain@example.com','2021-03-18 04:47:43','$2y$04$2AoRn/i9mRp1.YUbchI8Yu92lhh7zoYFhR65lXJeM2jqVBOtAWZeu','wWjHzZaVFP','2021-03-18 04:47:43','2021-03-18 04:47:43'),(40,'Prof. Ernestina Jacobs','bogisich.rosalee@example.org',NULL,'$2y$04$z30kgxHGD/J9G1nQ7W.o/O8d29qDnPRkb7yNOPOIyv28GzkH0iHqW',NULL,'2021-03-18 04:49:25','2021-03-18 04:49:25'),(41,'Nelda Little','deron04@example.net','2021-03-18 04:49:25','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','2STGZOJgH3','2021-03-18 04:49:25','2021-03-18 04:49:25'),(42,'Prof. Michael Stoltenberg MD','maida.fadel@example.org','2021-03-18 04:49:25','$2y$04$Hb3rKPeNr.mXKZQZyb88YO8NKyVs5jaiC44tjVgf2qBdOHiwV2o7m','nPrIZnyuv3','2021-03-18 04:49:25','2021-03-18 04:49:25');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-18 15:03:22
